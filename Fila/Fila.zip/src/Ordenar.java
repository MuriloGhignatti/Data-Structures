public class Ordenar {
    public static Fila<Integer> crescente(Fila<Integer> fila1, Fila<Integer> fila2){
        Fila<Integer> resultado = new Fila<>(Integer.class,10);
        int a = fila1.checkFirst();
        int b = fila2.checkFirst();
        while(!fila1.isEmpty() || !fila2.isEmpty()){
            if(!fila1.isEmpty()) a = fila1.checkFirst();
            if(!fila2.isEmpty()) b = fila2.checkFirst();
            if(fila1.isEmpty()) resultado.add(fila2.remove());
            if(fila2.isEmpty()) resultado.add(fila1.remove());
            if(a >= b && !fila2.isEmpty()) resultado.add(fila2.remove());
            else if(!fila1.isEmpty()) resultado.add(fila1.remove());
        }
        return resultado;
    }
}