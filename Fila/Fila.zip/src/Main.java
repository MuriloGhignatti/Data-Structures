public class Main {

    public static void main(String[] args) {
        Fila<Integer> fila1 = new Fila<>(Integer.class,4);
        Fila<Integer> fila2 = new Fila<>(Integer.class,5);

        fila1.add(12);
        fila1.add(35);
        fila1.add(52);
        fila1.add(64);

        fila2.add(5);
        fila2.add(15);
        fila2.add(23);
        fila2.add(55);
        fila2.add(75);

        Fila<Integer> resultado = Ordenar.crescente(fila1,fila2);

        while(!resultado.isEmpty()) System.out.println(resultado.remove());
    }

}